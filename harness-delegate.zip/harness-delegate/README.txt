Place your initialization script in init.sh, that you want to run before installing delegate.

Execute setup-proxy.sh to configure proxy settings.

Install the Harness Delegate by executing start.sh in this directory.
